package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentModel;
import com.example.demo.repository.UniversityRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class University {
	@Autowired private UniversityRepository unirepoRepository;
	@PostMapping("/student")
	private String addStudents(StudentModel student) {
		try {
			
			unirepoRepository.save(student);
			
			return "done";
		} catch (Exception e) {
			return e.getMessage();
		}
		
	}
	
	@GetMapping("/getall")
	public Iterable<StudentModel> getAllData() {
		return unirepoRepository.findAll();
	}
	

}
